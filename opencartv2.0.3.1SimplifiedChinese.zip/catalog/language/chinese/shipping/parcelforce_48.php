<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_title']       = '包裹 48';
$_['text_description'] = '包裹 48';
$_['text_weight']      = '重量:';
$_['text_insurance']   = '受保险于:';
$_['text_time']        = '预计时间:  48 小时内';