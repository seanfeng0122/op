<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_success'] = '成功: API 会话成功开启！';

// Error
$_['error_login']  = '警告: 用户名或密码不正确。';