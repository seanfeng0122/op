<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_currency'] = '货币';