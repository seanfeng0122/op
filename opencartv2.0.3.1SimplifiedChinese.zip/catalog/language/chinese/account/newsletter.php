<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']    = '订阅本站最新动态';

// Text
$_['text_account']     = '账户';
$_['text_newsletter']  = '新闻订阅';
$_['text_success']     = '成功: 您已更新订阅功能！';

// Entry
$_['entry_newsletter'] = '订阅';
