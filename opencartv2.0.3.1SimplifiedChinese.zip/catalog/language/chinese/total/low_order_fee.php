<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['text_low_order_fee'] = '小额订单收费';