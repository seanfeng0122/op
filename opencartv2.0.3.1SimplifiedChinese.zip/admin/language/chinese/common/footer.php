<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_footer'] 	= '<a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] 	= '版本号 %s';