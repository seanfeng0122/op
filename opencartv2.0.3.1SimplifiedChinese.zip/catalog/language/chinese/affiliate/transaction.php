<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']      = '我的交易';

// Column
$_['column_date_added']  = '添加日期';
$_['column_description'] = '描述';
$_['column_amount']      = '金额 (%s)';

// Text
$_['text_account']       = '账户';
$_['text_transaction']   = '交易';
$_['text_balance']       = '当前交易余额为:';
$_['text_empty']         = '尚无交易记录！';