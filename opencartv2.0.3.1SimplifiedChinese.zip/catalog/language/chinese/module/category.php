<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title'] = '商品分类';