<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_success']           = '已成功修改订单';

// Error
$_['error_permission']       = '警告: 无权限访问 API 接口！';
$_['error_customer']         = '需要设置会员资料！';
$_['error_payment_address']  = '需要账单地址！';
$_['error_payment_method']   = '需要支付方式！';
$_['error_shipping_address'] = '需要配送地址！';
$_['error_shipping_method']  = '需要配送方式！';
$_['error_stock']            = '标有 *** 的商品为库存少于您所需要的商品数量或库存不足！';
$_['error_minimum']          = '%s 的最小订单数量为 %s！';
$_['error_not_found']        = '警告: 无此订单！';