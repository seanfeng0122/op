<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= '警告: The payment gateway is in \'Sandbox Mode\'. Your account will not be charged.';
$_['text_total']	= 'Shipping, Handling, Discounts & Taxes';