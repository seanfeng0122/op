<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_title'] = 'Free Checkout';