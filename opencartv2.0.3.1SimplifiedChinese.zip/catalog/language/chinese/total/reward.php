<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_reward']   = '奖励积分 (%s)';
$_['text_order_id'] = '订单号: #%s';