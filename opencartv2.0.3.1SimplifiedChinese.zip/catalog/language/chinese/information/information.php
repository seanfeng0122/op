<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_error'] = '未找到该信息文章页！';