<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_voucher'] = '礼品券 (%s)';