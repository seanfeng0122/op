<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['text_sub_total'] = '小计';