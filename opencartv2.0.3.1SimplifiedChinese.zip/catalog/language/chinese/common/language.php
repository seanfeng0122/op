<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_language'] = '语言';