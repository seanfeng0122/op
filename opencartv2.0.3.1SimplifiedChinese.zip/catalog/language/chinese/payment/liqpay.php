<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_title'] = 'Credit Card / Debit Card (LiqPay)';