<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_success']     = '成功: 已修改购物车！';

// Error
$_['error_permission'] = '警告: 无权限方位该 API 接口！';
$_['error_stock']      = '标有 *** 的商品为库存少于您所需要的商品数量或库存不足！';
$_['error_minimum']    = '%s 的最小订单数量为 %s！';
$_['error_store']      = '无法从所选网店购买商品！';
$_['error_required']   = '%s 必须！';