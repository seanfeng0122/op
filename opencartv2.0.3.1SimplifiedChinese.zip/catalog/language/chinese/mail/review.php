<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_subject']	= '%s - 商品评论';
$_['text_waiting']	= '收到一新的商品评论等待审核。';
$_['text_product']	= '商品: %s';
$_['text_reviewer']	= '评论者: %s';
$_['text_rating']	= '评级: %s';
$_['text_review']	= '内容:';