<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title'] = '退出账号';

// Text
$_['text_message']  = '<p>已退出登录状态，可以安全离开电脑了。</p><p>您的购物车内容已被保存，当您再次登陆后，购物车的内容将被恢复。</p>';
$_['text_account']  = '账户';
$_['text_logout']   = '退出登录';