<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['text_handling'] = '手续费';