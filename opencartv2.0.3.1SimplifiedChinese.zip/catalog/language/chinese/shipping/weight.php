<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_title']  = '基于重量配送';
$_['text_weight'] = '重量:';