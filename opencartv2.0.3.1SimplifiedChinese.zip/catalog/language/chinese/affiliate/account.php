<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']        = '加盟账户';

// Text
$_['text_account']         = '账户';
$_['text_my_account']      = '加盟账户账户';
$_['text_my_tracking']     = '我的跟踪信息';
$_['text_my_transactions'] = '我的交易';
$_['text_edit']            = '编辑账户信息';
$_['text_password']        = '更改密码';
$_['text_payment']         = '更改预设支付方式';
$_['text_tracking']        = '定制会员跟踪链接';
$_['text_transaction']     = '查看我的交易记录';