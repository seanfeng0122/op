<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']    = '礼品券';

// Text
$_['text_total']       = '订单金额';
$_['text_success']     = '成功: 已修改礼品券！';
$_['text_edit']        = '编辑礼品券';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告: 无权限修改礼品券！';