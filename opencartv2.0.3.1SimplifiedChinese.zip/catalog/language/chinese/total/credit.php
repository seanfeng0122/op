<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['text_credit']   = '账户余额';
$_['text_order_id'] = '订单号: #%s';