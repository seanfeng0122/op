<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_coupon'] = '折扣券 (%s)';